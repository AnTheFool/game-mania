import pygame
import time
from typing import Optional, Tuple
from board import Board
from utils import apply_gcd_rule, calculate_score, format_time
from config import *

class Game:
    def __init__(self, mode: str):
        self.mode = mode
        self.mode_config = MODES[mode]
        self.board = Board(self.mode_config['size'], self.mode_config['max_value'], self.mode_config.get('min_value', 2))
        self.selected_cell = None
        self.hover_cell = None
        self.score = 0
        self.start_time = time.time()
        self.game_over = False
        self.victory = False
        self.message = ""
        self.last_path = []
        self.connection_path = []
        self.path_timer = 0
    
    def get_elapsed_time(self) -> float:
        """Get elapsed time in seconds"""
        if self.game_over:
            return self.end_time - self.start_time
        return time.time() - self.start_time
    
    def handle_cell_click(self, pos: Tuple[int, int]):
        """Handle clicking on a cell"""
        if self.game_over:
            return
        
        value = self.board.get_value(pos)
        if value is None:
            return
        
        if self.selected_cell is None:
            self.selected_cell = pos
            self.message = "Đã chọn ô có giá trị {}".format(value)
        else:
            if self.selected_cell == pos:
                self.selected_cell = None
                self.message = "Bỏ chọn"
                return
            
            # Try to connect
            if self.board.can_connect(self.selected_cell, pos):
                # Check if the move is actually useful (GCD > 1 or same values)
                val1 = self.board.get_value(self.selected_cell)
                val2 = self.board.get_value(pos)
                from utils import gcd
                
                if val1 == val2 or gcd(val1, val2) > 1:
                    self._process_connection(self.selected_cell, pos)
                else:
                    self.message = "Không thể nối! UCLN = 1 (nguyên tố cùng nhau)"
                    self.selected_cell = pos
            else:
                self.message = "Không thể nối 2 ô này!"
                self.selected_cell = pos
    
    def _process_connection(self, pos1: Tuple[int, int], pos2: Tuple[int, int]):
        """Process connection between two cells"""
        val1 = self.board.get_value(pos1)
        val2 = self.board.get_value(pos2)
        
        if val1 is None or val2 is None:
            return
        
        # Store path for animation
        self.connection_path = self.board.last_path.copy() if hasattr(self.board, 'last_path') else []
        self.path_timer = 0.5  # Show path for 0.5 seconds
        
        # Calculate score
        points = calculate_score(val1, val2)
        self.score += points
        
        # Apply rule
        new_val1, new_val2, gcd_val = apply_gcd_rule(val1, val2)
        
        # Update board
        self.board.set_value(pos1, new_val1)
        self.board.set_value(pos2, new_val2)
        
        # Update message
        if val1 == val2:
            self.message = "Nối {} = {}! +{} điểm".format(val1, val2, points)
        elif new_val1 is None and new_val2 is None:
            self.message = "Nối {} và {}, UCLN={}, cả 2 ô biến mất! +{} điểm".format(val1, val2, gcd_val, points)
        elif new_val1 is None:
            self.message = "Nối {} và {}, UCLN={}, {} biến mất, {}→{}! +{} điểm".format(val1, val2, gcd_val, val1, val2, new_val2, points)
        elif new_val2 is None:
            self.message = "Nối {} và {}, UCLN={}, {} biến mất, {}→{}! +{} điểm".format(val1, val2, gcd_val, val2, val1, new_val1, points)
        else:
            self.message = "Nối {} và {}, UCLN={}, {}→{}, {}→{}! +{} điểm".format(val1, val2, gcd_val, val1, new_val1, val2, new_val2, points)
        
        self.selected_cell = None
        
        # Check game state
        self._check_game_state()
    
    def _check_game_state(self):
        """Check if game is won or lost"""
        if self.board.is_empty():
            self.game_over = True
            self.victory = True
            self.end_time = time.time()
            self.message = "CHIẾN THẮNG! Điểm: {}, Thời gian: {}".format(self.score, format_time(self.get_elapsed_time()))
        elif not self.board.has_valid_moves():
            self.game_over = True
            self.victory = False
            self.end_time = time.time()
            self.message = "THUA CUỘC! Không còn nước đi hợp lệ. Điểm: {}".format(self.score)
    
    def draw(self, screen: pygame.Surface):
        """Draw the game"""
        # Update path timer
        if self.path_timer > 0:
            self.path_timer -= 1/60.0  # Decrease by frame time
            if self.path_timer <= 0:
                self.connection_path = []
        
        # Calculate cell size
        board_area_width = SCREEN_WIDTH - SIDE_PANEL_WIDTH - 40
        board_area_height = SCREEN_HEIGHT - 200
        
        cell_size = min(board_area_width // self.board.size, 
                       board_area_height // self.board.size) - CELL_MARGIN
        
        board_width = (cell_size + CELL_MARGIN) * self.board.size
        board_height = (cell_size + CELL_MARGIN) * self.board.size
        
        board_x = (SCREEN_WIDTH - SIDE_PANEL_WIDTH - board_width) // 2
        board_y = 120
        
        # Store board position for click detection
        self.board_offset = (board_x, board_y)
        self.cell_size = cell_size
        
        # Draw connection path first (under cells)
        if self.connection_path:
            self._draw_connection_path(screen, board_x, board_y, cell_size)
        
        # Draw cells
        font = pygame.font.SysFont(FONT_NAME, min(cell_size // 2, 48), bold=True)
        
        for i in range(self.board.size):
            for j in range(self.board.size):
                x = board_x + j * (cell_size + CELL_MARGIN)
                y = board_y + i * (cell_size + CELL_MARGIN)
                
                value = self.board.get_value((i, j))
                if value is None:
                    continue
                
                # Determine cell color
                if (i, j) == self.selected_cell:
                    color = CELL_SELECTED
                elif (i, j) == self.hover_cell:
                    color = CELL_HOVER
                else:
                    color = CELL_BG
                
                # Draw cell
                pygame.draw.rect(screen, color, (x, y, cell_size, cell_size))
                pygame.draw.rect(screen, CELL_BORDER, (x, y, cell_size, cell_size), 3)
                
                # Draw value
                text = font.render(str(value), True, WHITE)
                text_rect = text.get_rect(center=(x + cell_size // 2, y + cell_size // 2))
                screen.blit(text, text_rect)
        
        # Draw side panel
        self._draw_side_panel(screen)
        
        # Draw message
        self._draw_message(screen)
    
    def _draw_connection_path(self, screen: pygame.Surface, board_x: int, board_y: int, cell_size: int):
        """Draw the connection path between two cells"""
        if len(self.connection_path) < 2:
            return
        
        # Convert board positions to screen coordinates
        points = []
        for r, c in self.connection_path:
            # Handle positions outside the board
            if r < 0:
                y = board_y - (cell_size + CELL_MARGIN)
            elif r >= self.board.size:
                y = board_y + self.board.size * (cell_size + CELL_MARGIN)
            else:
                y = board_y + r * (cell_size + CELL_MARGIN) + cell_size // 2
            
            if c < 0:
                x = board_x - (cell_size + CELL_MARGIN)
            elif c >= self.board.size:
                x = board_x + self.board.size * (cell_size + CELL_MARGIN)
            else:
                x = board_x + c * (cell_size + CELL_MARGIN) + cell_size // 2
            
            points.append((x, y))
        
        # Draw lines
        if len(points) >= 2:
            pygame.draw.lines(screen, ORANGE, False, points, 5)
    
    def _draw_side_panel(self, screen: pygame.Surface):
        """Draw side panel with game info"""
        panel_x = SCREEN_WIDTH - SIDE_PANEL_WIDTH
        
        # Background
        pygame.draw.rect(screen, LIGHT_GRAY, (panel_x, 0, SIDE_PANEL_WIDTH, SCREEN_HEIGHT))
        pygame.draw.line(screen, BLUE, (panel_x, 0), (panel_x, SCREEN_HEIGHT), 3)
        
        # Title
        font_title = pygame.font.SysFont(FONT_NAME, 32, bold=True)
        font_info = pygame.font.SysFont(FONT_NAME, 28)
        
        y = 20
        
        title = font_title.render("THÔNG TIN", True, YELLOW)
        screen.blit(title, (panel_x + 20, y))
        y += 50
        
        # Mode
        mode_text = font_info.render("Độ khó:", True, WHITE)
        screen.blit(mode_text, (panel_x + 20, y))
        y += 30
        mode_name = font_info.render(self.mode_config['name'], True, CYAN)
        screen.blit(mode_name, (panel_x + 20, y))
        y += 50
        
        # Score
        score_text = font_info.render("Điểm:", True, WHITE)
        screen.blit(score_text, (panel_x + 20, y))
        y += 30
        score_val = font_title.render(str(self.score), True, GREEN)
        screen.blit(score_val, (panel_x + 20, y))
        y += 50
        
        # Time
        time_text = font_info.render("Thời gian:", True, WHITE)
        screen.blit(time_text, (panel_x + 20, y))
        y += 30
        time_val = font_info.render(format_time(self.get_elapsed_time()), True, ORANGE)
        screen.blit(time_val, (panel_x + 20, y))
        y += 50
        
        # Cells remaining
        cells_text = font_info.render("Ô còn lại:", True, WHITE)
        screen.blit(cells_text, (panel_x + 20, y))
        y += 30
        cells_val = font_info.render(str(self.board.count_cells()), True, PURPLE)
        screen.blit(cells_val, (panel_x + 20, y))
    
    def _draw_message(self, screen: pygame.Surface):
        """Draw message at bottom"""
        font = pygame.font.SysFont(FONT_NAME, 28)
        text = font.render(self.message, True, WHITE)
        text_rect = text.get_rect(center=(SCREEN_WIDTH // 2 - SIDE_PANEL_WIDTH // 2, SCREEN_HEIGHT - 40))
        
        # Background
        bg_rect = text_rect.inflate(20, 10)
        pygame.draw.rect(screen, LIGHT_GRAY, bg_rect)
        pygame.draw.rect(screen, BLUE, bg_rect, 2)
        
        screen.blit(text, text_rect)
    
    def get_cell_at_pos(self, mouse_pos: Tuple[int, int]) -> Optional[Tuple[int, int]]:
        """Get cell position from mouse position"""
        if not hasattr(self, 'board_offset'):
            return None
        
        mx, my = mouse_pos
        bx, by = self.board_offset
        
        if mx < bx or my < by:
            return None
        
        col = (mx - bx) // (self.cell_size + CELL_MARGIN)
        row = (my - by) // (self.cell_size + CELL_MARGIN)
        
        if 0 <= row < self.board.size and 0 <= col < self.board.size:
            return (row, col)
        return None
