import random
from typing import List, Tuple, Optional, Set
from collections import deque
import copy

class Board:
    def __init__(self, size: int, max_value: int, min_value: int = 2):
        self.size = size
        self.max_value = max_value
        self.min_value = min_value
        self.grid = [[None for _ in range(size)] for _ in range(size)]
        self.last_path = []
        self.generate_solvable_board()
    
    def generate_solvable_board(self):
        """Generate a board with even count of all prime factors (guaranteed solvable)"""
        max_attempts = 150
        for attempt in range(max_attempts):
            self._generate_balanced_board()
            # Verify the board has even prime counts and has valid moves
            from utils import all_prime_counts_even
            values = [cell for row in self.grid for cell in row if cell is not None]
            
            # Check diversity: no value should appear more than 25% of the time
            if len(values) > 0:
                from collections import Counter
                counts = Counter(values)
                max_count = max(counts.values())
                if max_count > len(values) // 4:
                    continue  # Too many duplicates, try again
            
            if all_prime_counts_even(values) and self._has_multiple_solutions():
                return
        
        # Fallback: generate simple diverse board
        self._generate_simple_solvable_board()
    
    def _generate_balanced_board(self):
        """Generate board ensuring all prime factors appear even number of times"""
        from utils import prime_factorization, count_total_prime_factors
        
        total_cells = self.size * self.size
        max_same = total_cells // 4  # Max 25% same values
        values = []
        value_counts = {}
        
        # Start with some base numbers
        primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47]
        available_primes = [p for p in primes if p <= min(self.max_value // 2, 100)]
        
        if len(available_primes) < 3:
            available_primes = [2, 3, 5, 7, 11, 13]
        
        # Calculate a good base multiplier to get numbers in range
        base_multiplier = max(1, self.min_value // 10)
        
        # Generate random numbers for most of the board
        target_cells = total_cells - 8  # Leave room for balancing
        attempts = 0
        max_attempts = target_cells * 3
        
        while len(values) < target_cells and attempts < max_attempts:
            attempts += 1
            
            # Create number from 1-3 random primes
            num_primes = random.randint(1, min(3, len(available_primes)))
            selected = random.sample(available_primes, num_primes)
            
            value = base_multiplier
            for p in selected:
                # Use power 1-2 for this prime
                power = random.randint(1, 2)
                value *= (p ** power)
            
            # Scale to fit in range [min_value, max_value]
            if value < self.min_value:
                # Scale up
                multiplier = (self.min_value // value) + random.randint(1, 3)
                value *= multiplier
            
            while value > self.max_value and value > self.min_value:
                value //= random.choice([2, 3])
            
            # Ensure in valid range
            if value < self.min_value:
                value = random.randint(self.min_value, min(self.min_value * 10, self.max_value))
            
            # Avoid multiples of 10 for hard/expert modes
            if self.min_value >= 20 and value % 10 == 0:
                offset = random.choice([1, 2, 3, 4, 5, 6, 7, 8, 9])
                value += offset
                if value > self.max_value:
                    value -= 10 + offset
            
            # Ensure diversity - don't add if we already have too many of this value
            if self.min_value <= value <= self.max_value:
                if value_counts.get(value, 0) < max_same:
                    values.append(value)
                    value_counts[value] = value_counts.get(value, 0) + 1
        
        # If we couldn't generate enough, add some diversity
        while len(values) < target_cells:
            value = random.randint(self.min_value, min(self.min_value * 20, self.max_value))
            # Avoid multiples of 10
            if self.min_value >= 20 and value % 10 == 0:
                value += random.choice([1, 3, 7])
            if value_counts.get(value, 0) < max_same:
                values.append(value)
                value_counts[value] = value_counts.get(value, 0) + 1
        
        # Now balance the prime counts
        current_counts = count_total_prime_factors(values)
        
        # Find primes with odd counts
        odd_primes = {prime: count for prime, count in current_counts.items() if count % 2 != 0}
        
        # Add numbers to balance the odd primes
        balance_attempts = 0
        while len(values) < total_cells and balance_attempts < 100:
            balance_attempts += 1
            
            if not odd_primes:
                # Just add diverse values
                value = random.randint(self.min_value, min(self.min_value * 15, self.max_value))
                # Avoid multiples of 10
                if self.min_value >= 20 and value % 10 == 0:
                    value += random.choice([1, 3, 7])
                if value_counts.get(value, 0) < max_same:
                    values.append(value)
                    value_counts[value] = value_counts.get(value, 0) + 1
            else:
                # Pick some odd primes to balance
                primes_to_balance = list(odd_primes.keys())[:min(2, len(odd_primes))]
                
                value = base_multiplier
                for p in primes_to_balance:
                    value *= p
                
                # Scale to fit range
                if value < self.min_value:
                    multiplier = (self.min_value // value) + 1
                    value *= multiplier
                
                while value > self.max_value and value > self.min_value:
                    value //= 2
                
                # Avoid multiples of 10
                if self.min_value >= 20 and value % 10 == 0:
                    value += random.choice([1, 3, 7])
                
                if self.min_value <= value <= self.max_value:
                    if value_counts.get(value, 0) < max_same:
                        values.append(value)
                        value_counts[value] = value_counts.get(value, 0) + 1
                        # Update counts
                        current_counts = count_total_prime_factors(values)
                        odd_primes = {prime: count for prime, count in current_counts.items() if count % 2 != 0}
        
        # Fill remaining cells
        while len(values) < total_cells:
            value = random.randint(self.min_value, min(self.min_value * 10, self.max_value))
            # Avoid multiples of 10
            if self.min_value >= 20 and value % 10 == 0:
                value += random.choice([1, 3, 7])
            if value_counts.get(value, 0) < max_same:
                values.append(value)
                value_counts[value] = value_counts.get(value, 0) + 1
        
        # Trim to exact size
        values = values[:total_cells]
        
        # Final balance pass
        current_counts = count_total_prime_factors(values)
        odd_primes = {prime: count for prime, count in current_counts.items() if count % 2 != 0}
        
        if odd_primes:
            # Replace some values to balance (up to 25% of board)
            num_replacements = min(len(odd_primes) * 2, total_cells // 4)
            replace_indices = random.sample(range(len(values)), num_replacements)
            
            for idx in replace_indices:
                if not odd_primes:
                    break
                    
                primes_to_use = list(odd_primes.keys())[:min(2, len(odd_primes))]
                value = base_multiplier
                for p in primes_to_use:
                    value *= p
                
                # Ensure in range
                if value < self.min_value:
                    value *= ((self.min_value // value) + 1)
                    
                while value > self.max_value:
                    value //= 2
                
                # Avoid multiples of 10
                if self.min_value >= 20 and value % 10 == 0:
                    value += random.choice([1, 3, 7])
                    if value > self.max_value:
                        value -= 10
                
                if self.min_value <= value <= self.max_value:
                    values[idx] = value
                
                current_counts = count_total_prime_factors(values)
                odd_primes = {prime: count for prime, count in current_counts.items() if count % 2 != 0}
        
        random.shuffle(values)
        
        # Fill grid
        idx = 0
        for i in range(self.size):
            for j in range(self.size):
                self.grid[i][j] = values[idx] if idx < len(values) else self.min_value
                idx += 1
    
    def _generate_simple_solvable_board(self):
        """Generate a simple board that's definitely solvable with diversity"""
        from utils import all_prime_counts_even, count_total_prime_factors
        
        total_cells = self.size * self.size
        values = []
        
        # Use base values scaled to min_value
        if self.min_value >= 20:
            # For hard/expert modes - avoid multiples of 10
            base_values = [21, 28, 33, 35, 42, 49, 56, 63, 66, 77, 84, 91, 99, 105, 132, 143, 154, 165]
        else:
            # For easy/medium modes
            base_values = [6, 10, 12, 15, 20, 30]
        
        max_same = total_cells // 4  # Max 25% can be the same
        
        # Count for each value
        value_counts = {}
        
        while len(values) < total_cells:
            # Pick a random base value
            base = random.choice(base_values)
            
            # Create variations: base, base*2, base*3, etc.
            max_mult = max(2, min(5, self.max_value // base))
            multiplier = random.randint(1, max_mult)
            value = min(base * multiplier, self.max_value)
            
            # For hard/expert modes, avoid multiples of 10
            if self.min_value >= 20 and value % 10 == 0:
                # Add a small offset to avoid ending in 0
                offset = random.choice([1, 2, 3, 4, 5, 6, 7, 8, 9])
                value += offset
                if value > self.max_value:
                    value -= 10 + offset
            
            # Ensure value is at least min_value
            if value < self.min_value:
                value = self.min_value
            
            # Check if adding this value would exceed the max_same limit
            if value_counts.get(value, 0) < max_same:
                values.append(value)
                value_counts[value] = value_counts.get(value, 0) + 1
            else:
                # Try a different value
                for attempt in range(10):
                    alt_base = random.choice(base_values)
                    alt_mult = random.randint(1, max(2, min(5, self.max_value // alt_base)))
                    alt_value = min(alt_base * alt_mult, self.max_value)
                    
                    # Avoid multiples of 10 for hard/expert
                    if self.min_value >= 20 and alt_value % 10 == 0:
                        offset = random.choice([1, 2, 3, 4, 5, 6, 7, 8, 9])
                        alt_value += offset
                        if alt_value > self.max_value:
                            alt_value -= 10 + offset
                    
                    if alt_value < self.min_value:
                        alt_value = self.min_value
                    if alt_value >= self.min_value and value_counts.get(alt_value, 0) < max_same:
                        values.append(alt_value)
                        value_counts[alt_value] = value_counts.get(alt_value, 0) + 1
                        break
                else:
                    # If still can't find, add a random value in range
                    rand_val = random.randint(self.min_value, min(self.min_value * 10, self.max_value))
                    # Avoid multiples of 10
                    if self.min_value >= 20 and rand_val % 10 == 0:
                        rand_val += random.choice([1, 3, 7])
                    values.append(rand_val)
                    value_counts[rand_val] = value_counts.get(rand_val, 0) + 1
        
        # Balance prime factors
        current_counts = count_total_prime_factors(values)
        odd_primes = {prime: count for prime, count in current_counts.items() if count % 2 != 0}
        
        # Replace some values to balance
        if odd_primes and len(values) > 0:
            replace_indices = random.sample(range(len(values)), min(len(odd_primes) * 2, len(values) // 3))
            for idx in replace_indices:
                if not odd_primes:
                    break
                
                primes_to_use = list(odd_primes.keys())[:min(2, len(odd_primes))]
                value = 1
                for p in primes_to_use:
                    value *= p
                
                # Scale to fit range
                if value < self.min_value:
                    multiplier = (self.min_value // value) + 1
                    value *= multiplier
                
                while value > self.max_value and value > self.min_value:
                    value //= 2
                
                # Avoid multiples of 10 for hard/expert
                if self.min_value >= 20 and value % 10 == 0:
                    value += random.choice([1, 3, 7])
                    if value > self.max_value:
                        value -= 10
                
                if self.min_value <= value <= self.max_value:
                    values[idx] = value
                
                current_counts = count_total_prime_factors(values)
                odd_primes = {prime: count for prime, count in current_counts.items() if count % 2 != 0}
        
        random.shuffle(values)
        
        # Fill grid
        idx = 0
        for i in range(self.size):
            for j in range(self.size):
                self.grid[i][j] = values[idx] if idx < len(values) else self.min_value
                idx += 1

    def _has_multiple_solutions(self) -> bool:
        """Check if board has at least 2 different valid moves"""
        solutions = []
        
        for i in range(self.size):
            for j in range(self.size):
                if self.grid[i][j] is None:
                    continue
                for x in range(self.size):
                    for y in range(self.size):
                        if (i, j) != (x, y) and self.grid[x][y] is not None:
                            if self.can_connect((i, j), (x, y)):
                                solutions.append(((i, j), (x, y)))
                                if len(solutions) >= 2:
                                    return True
        return len(solutions) >= 2
    
    def can_connect(self, pos1: Tuple[int, int], pos2: Tuple[int, int], 
                   grid: Optional[List[List[Optional[int]]]] = None) -> bool:
        """Check if two positions can be connected with max 2 turns (Pikachu rule)"""
        if grid is None:
            grid = self.grid
        
        r1, c1 = pos1
        r2, c2 = pos2
        
        if pos1 == pos2:
            return False
        
        val1 = grid[r1][c1]
        val2 = grid[r2][c2]
        
        if val1 is None or val2 is None:
            return False
        
        # Try all possible paths with 0, 1, or 2 turns
        # Check direct line (0 turns)
        path = self._check_line(pos1, pos2, grid)
        if path:
            self.last_path = path
            return True
        
        # Check L-shape (1 turn)
        path = self._check_l_path(pos1, pos2, grid)
        if path:
            self.last_path = path
            return True
        
        # Check Z-shape and U-shape (2 turns)
        path = self._check_z_path(pos1, pos2, grid)
        if path:
            self.last_path = path
            return True
        
        self.last_path = []
        return False
    
    def _is_empty_or_endpoint(self, pos: Tuple[int, int], end1: Tuple[int, int], 
                              end2: Tuple[int, int], grid: List[List[Optional[int]]]) -> bool:
        """Check if position is empty or one of the endpoints"""
        r, c = pos
        if pos == end1 or pos == end2:
            return True
        if 0 <= r < self.size and 0 <= c < self.size:
            return grid[r][c] is None
        # Allow positions outside the board (for U-shaped paths)
        if r < 0 or r >= self.size or c < 0 or c >= self.size:
            return True
        return False
    
    def _check_line(self, pos1: Tuple[int, int], pos2: Tuple[int, int], 
                    grid: List[List[Optional[int]]]):
        """Check if there's a direct line between two positions, return path if exists"""
        r1, c1 = pos1
        r2, c2 = pos2
        
        # Horizontal line
        if r1 == r2:
            # Check if row is within bounds
            if 0 <= r1 < self.size:
                min_c, max_c = min(c1, c2), max(c1, c2)
                for c in range(max(0, min_c + 1), min(self.size, max_c)):
                    if grid[r1][c] is not None:
                        return None
            return [pos1, pos2]
        
        # Vertical line
        if c1 == c2:
            # Check if column is within bounds
            if 0 <= c1 < self.size:
                min_r, max_r = min(r1, r2), max(r1, r2)
                for r in range(max(0, min_r + 1), min(self.size, max_r)):
                    if grid[r][c1] is not None:
                        return None
            return [pos1, pos2]
        
        return None
    
    def _check_l_path(self, pos1: Tuple[int, int], pos2: Tuple[int, int], 
                      grid: List[List[Optional[int]]]):
        """Check L-shaped path (1 turn), return path if exists"""
        r1, c1 = pos1
        r2, c2 = pos2
        
        # Try corner at (r1, c2)
        corner1 = (r1, c2)
        if self._is_empty_or_endpoint(corner1, pos1, pos2, grid):
            path1 = self._check_line(pos1, corner1, grid)
            path2 = self._check_line(corner1, pos2, grid)
            if path1 and path2:
                return [pos1, corner1, pos2]
        
        # Try corner at (r2, c1)
        corner2 = (r2, c1)
        if self._is_empty_or_endpoint(corner2, pos1, pos2, grid):
            path1 = self._check_line(pos1, corner2, grid)
            path2 = self._check_line(corner2, pos2, grid)
            if path1 and path2:
                return [pos1, corner2, pos2]
        
        return None
    
    def _check_z_path(self, pos1: Tuple[int, int], pos2: Tuple[int, int], 
                      grid: List[List[Optional[int]]]):
        """Check Z-shaped and U-shaped path (2 turns), return path if exists"""
        r1, c1 = pos1
        r2, c2 = pos2
        
        # Try horizontal first, then vertical, then horizontal (Z-shape inside board)
        for c in range(self.size):
            if c == c1:
                continue
            mid1 = (r1, c)
            if not self._is_empty_or_endpoint(mid1, pos1, pos2, grid):
                continue
            path1 = self._check_line(pos1, mid1, grid)
            if not path1:
                continue
            
            mid2 = (r2, c)
            if self._is_empty_or_endpoint(mid2, pos1, pos2, grid):
                path2 = self._check_line(mid1, mid2, grid)
                path3 = self._check_line(mid2, pos2, grid)
                if path2 and path3:
                    return [pos1, mid1, mid2, pos2]
        
        # Try vertical first, then horizontal, then vertical (Z-shape inside board)
        for r in range(self.size):
            if r == r1:
                continue
            mid1 = (r, c1)
            if not self._is_empty_or_endpoint(mid1, pos1, pos2, grid):
                continue
            path1 = self._check_line(pos1, mid1, grid)
            if not path1:
                continue
            
            mid2 = (r, c2)
            if self._is_empty_or_endpoint(mid2, pos1, pos2, grid):
                path2 = self._check_line(mid1, mid2, grid)
                path3 = self._check_line(mid2, pos2, grid)
                if path2 and path3:
                    return [pos1, mid1, mid2, pos2]
        
        # Try U-shaped paths going outside the board (top edge)
        if r1 >= 0 and r2 >= 0:
            # Check if we can go up from both positions
            can_go_up_1 = True
            for r in range(0, r1):
                if grid[r][c1] is not None:
                    can_go_up_1 = False
                    break
            
            can_go_up_2 = True
            for r in range(0, r2):
                if grid[r][c2] is not None:
                    can_go_up_2 = False
                    break
            
            if can_go_up_1 and can_go_up_2:
                mid1 = (-1, c1)
                mid2 = (-1, c2)
                path1 = self._check_line(pos1, mid1, grid)
                path2 = self._check_line(mid1, mid2, grid)
                path3 = self._check_line(mid2, pos2, grid)
                if path1 and path2 and path3:
                    return [pos1, mid1, mid2, pos2]
        
        # Try U-shaped paths going outside the board (bottom edge)
        if r1 < self.size and r2 < self.size:
            can_go_down_1 = True
            for r in range(r1 + 1, self.size):
                if grid[r][c1] is not None:
                    can_go_down_1 = False
                    break
            
            can_go_down_2 = True
            for r in range(r2 + 1, self.size):
                if grid[r][c2] is not None:
                    can_go_down_2 = False
                    break
            
            if can_go_down_1 and can_go_down_2:
                mid1 = (self.size, c1)
                mid2 = (self.size, c2)
                path1 = self._check_line(pos1, mid1, grid)
                path2 = self._check_line(mid1, mid2, grid)
                path3 = self._check_line(mid2, pos2, grid)
                if path1 and path2 and path3:
                    return [pos1, mid1, mid2, pos2]
        
        # Try U-shaped paths going outside the board (left edge)
        if c1 >= 0 and c2 >= 0:
            can_go_left_1 = True
            for c in range(0, c1):
                if grid[r1][c] is not None:
                    can_go_left_1 = False
                    break
            
            can_go_left_2 = True
            for c in range(0, c2):
                if grid[r2][c] is not None:
                    can_go_left_2 = False
                    break
            
            if can_go_left_1 and can_go_left_2:
                mid1 = (r1, -1)
                mid2 = (r2, -1)
                path1 = self._check_line(pos1, mid1, grid)
                path2 = self._check_line(mid1, mid2, grid)
                path3 = self._check_line(mid2, pos2, grid)
                if path1 and path2 and path3:
                    return [pos1, mid1, mid2, pos2]
        
        # Try U-shaped paths going outside the board (right edge)
        if c1 < self.size and c2 < self.size:
            can_go_right_1 = True
            for c in range(c1 + 1, self.size):
                if grid[r1][c] is not None:
                    can_go_right_1 = False
                    break
            
            can_go_right_2 = True
            for c in range(c2 + 1, self.size):
                if grid[r2][c] is not None:
                    can_go_right_2 = False
                    break
            
            if can_go_right_1 and can_go_right_2:
                mid1 = (r1, self.size)
                mid2 = (r2, self.size)
                path1 = self._check_line(pos1, mid1, grid)
                path2 = self._check_line(mid1, mid2, grid)
                path3 = self._check_line(mid2, pos2, grid)
                if path1 and path2 and path3:
                    return [pos1, mid1, mid2, pos2]
        
        return None
    
    def get_value(self, pos: Tuple[int, int]) -> Optional[int]:
        """Get value at position"""
        r, c = pos
        if 0 <= r < self.size and 0 <= c < self.size:
            return self.grid[r][c]
        return None
    
    def set_value(self, pos: Tuple[int, int], value: Optional[int]):
        """Set value at position"""
        r, c = pos
        if 0 <= r < self.size and 0 <= c < self.size:
            self.grid[r][c] = value
    
    def is_empty(self) -> bool:
        """Check if board is completely empty"""
        for row in self.grid:
            for cell in row:
                if cell is not None:
                    return False
        return True
    
    def count_cells(self) -> int:
        """Count non-empty cells"""
        count = 0
        for row in self.grid:
            for cell in row:
                if cell is not None:
                    count += 1
        return count
    
    def has_valid_moves(self) -> bool:
        """Check if there are any valid moves left"""
        # Collect all remaining values
        remaining_values = []
        for row in self.grid:
            for cell in row:
                if cell is not None:
                    remaining_values.append(cell)
        
        # If empty or only 1 cell, no valid moves
        if len(remaining_values) <= 1:
            return False
        
        # Check if any pair can be connected
        for i in range(self.size):
            for j in range(self.size):
                if self.grid[i][j] is None:
                    continue
                for x in range(self.size):
                    for y in range(self.size):
                        if (i, j) != (x, y) and self.grid[x][y] is not None:
                            # Check if they can be connected
                            if self.can_connect((i, j), (x, y)):
                                # Check if this move would change the board
                                from utils import gcd
                                val1 = self.grid[i][j]
                                val2 = self.grid[x][y]
                                
                                # Same values or GCD > 1 means valid move
                                if val1 == val2 or gcd(val1, val2) > 1:
                                    return True
        
        # If we reach here, all remaining pairs are coprime and can't be connected
        # or can be connected but GCD=1 (no change)
        return False
