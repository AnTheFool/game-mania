# TRÒ CHƠI "SỐ LIÊN TRANH BÁ"

Game puzzle toán học dựa trên cơ chế "Nối Pikachu" với yếu tố ước chung lớn nhất (UCLN).

## Mô tả trò chơi

Người chơi nối các ô số lại với nhau theo luật Pikachu (tối đa 3 đường thẳng, 2 lần rẽ). Khi nối thành công:
- **Nếu 2 số giống nhau**: Cả 2 ô biến mất
- **Nếu 2 số khác nhau**: Chia cả 2 số cho UCLN
  - Số nào có thương = 1 sẽ biến mất
  - Số nào có thương > 1 sẽ được thay bằng thương đó

### Ví dụ

**Ví dụ 1:** Nối 9 với 3 (UCLN = 3)
```
9 / 3 = 3  →  Ô này còn lại, giá trị = 3
3 / 3 = 1  →  Ô này biến mất
```

**Ví dụ 2:** Nối 12 và 20 (UCLN = 4)
```
12 / 4 = 3  →  Thay 12 bằng 3
20 / 4 = 5  →  Thay 20 bằng 5
```

**Ví dụ 3:** Nối 10 và 17 (UCLN = 1)
```
Không có thay đổi (2 số nguyên tố cùng nhau)
```

## Độ khó

| Độ khó | Kích thước | Giá trị số |
|--------|-----------|------------|
| DỄ | 4x4 | 2-50 |
| TRUNG BÌNH | 6x6 | 2-100 |
| KHÓ | 8x8 | 2-200 |
| SIÊU TRÍ TUỆ | 10x10 | 2-1000 |

## Cách tính điểm

- **100 điểm**: Nối 2 ô giống nhau
- **50 điểm**: Nối 2 ô có UCLN > 1 và 1 ô biến mất
- **10 điểm**: Nối 2 ô có UCLN > 1 nhưng cả 2 ô còn lại

## Điều kiện thắng/thua

- **Chiến thắng**: Clear hết tất cả ô trên bảng
- **Thua cuộc**: Còn ô trên bảng nhưng không còn nước đi hợp lệ

## Cài đặt và chạy game

### Yêu cầu
- Python 3.8+
- Pygame 2.5.0+

### Cài đặt

```bash
pip install -r requirements.txt
```

### Chạy game

```bash
python main.py
```

## Cấu trúc project

```
so_lien_tranh_ba/
├── main.py              # Game loop chính và menu
├── game.py              # Logic game và xử lý sự kiện
├── board.py             # Board generation và pathfinding
├── utils.py             # Hàm tiện ích (UCLN, scoring)
├── config.py            # Configuration và constants
├── requirements.txt     # Dependencies
└── README.md           # Tài liệu này
```

## Điều khiển

- **Click chuột**: Chọn ô và nối các ô
- **ESC**: Quay lại menu chính

## Tính năng

✅ 4 độ khó với kích thước bảng khác nhau  
✅ Thuật toán Pikachu pathfinding (BFS với tối đa 2 rẽ)  
✅ Tính toán UCLN và áp dụng luật chơi  
✅ Hệ thống điểm và timer  
✅ Đảm bảo bảng có ít nhất 2 solution khi khởi tạo  
✅ Kiểm tra điều kiện thắng/thua tự động  
✅ UI trực quan với panel thông tin  

---

**Phát triển bởi:** Kiro AI Assistant  
**Framework:** Pygame 