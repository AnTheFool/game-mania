import pygame
import sys
from config import *
from game import Game
from utils import format_time

class MenuButton:
    def __init__(self, x, y, width, height, text, mode):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.mode = mode
        self.hovered = False
    
    def draw(self, screen):
        color = BLUE if self.hovered else LIGHT_GRAY
        pygame.draw.rect(screen, color, self.rect)
        pygame.draw.rect(screen, WHITE, self.rect, 3)
        
        font = pygame.font.SysFont(FONT_NAME, 28, bold=True)
        text = font.render(self.text, True, WHITE)
        text_rect = text.get_rect(center=self.rect.center)
        screen.blit(text, text_rect)
    
    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.hovered:
                return self.mode
        return None

class Menu:
    def __init__(self, screen):
        self.screen = screen
        self.buttons = []
        
        # Create buttons
        start_y = 200
        spacing = BUTTON_HEIGHT + BUTTON_MARGIN
        
        modes = [
            ('EASY', 'DỄ'),
            ('MEDIUM', 'TRUNG BÌNH'),
            ('HARD', 'KHÓ'),
            ('EXPERT', 'SIÊU TRÍ TUỆ')
        ]
        
        for i, (mode, text) in enumerate(modes):
            x = (SCREEN_WIDTH - BUTTON_WIDTH) // 2
            y = start_y + i * spacing
            self.buttons.append(MenuButton(x, y, BUTTON_WIDTH, BUTTON_HEIGHT, text, mode))
    
    def draw(self):
        self.screen.fill(BG_COLOR)
        
        # Title
        font_title = pygame.font.SysFont(FONT_NAME, 64, bold=True)
        title = font_title.render("SỐ LIÊN TRANH BÁ", True, YELLOW)
        title_rect = title.get_rect(center=(SCREEN_WIDTH // 2, 100))
        self.screen.blit(title, title_rect)
        
        # Subtitle
        font_sub = pygame.font.SysFont(FONT_NAME, 28)
        subtitle = font_sub.render("Chọn độ khó:", True, WHITE)
        subtitle_rect = subtitle.get_rect(center=(SCREEN_WIDTH // 2, 160))
        self.screen.blit(subtitle, subtitle_rect)
        
        # Buttons
        for button in self.buttons:
            button.draw(self.screen)
        
        # Instructions
        font_inst = pygame.font.SysFont(FONT_NAME, 20)
        instructions = [
            "Luật chơi: Nối các ô giống nhau hoặc có UCLN > 1",
            "Chiến thắng khi clear hết bảng",
            "Thua cuộc khi không còn nước đi hợp lệ"
        ]
        
        y = SCREEN_HEIGHT - 100
        for inst in instructions:
            text = font_inst.render(inst, True, GRAY)
            text_rect = text.get_rect(center=(SCREEN_WIDTH // 2, y))
            self.screen.blit(text, text_rect)
            y += 25
    
    def handle_event(self, event):
        for button in self.buttons:
            result = button.handle_event(event)
            if result:
                return result
        return None

class GameOverScreen:
    def __init__(self, screen, victory, score, time_str):
        self.screen = screen
        self.victory = victory
        self.score = score
        self.time_str = time_str
        
        # Create buttons
        self.menu_button = MenuButton(
            SCREEN_WIDTH // 2 - BUTTON_WIDTH - 10,
            SCREEN_HEIGHT // 2 + 100,
            BUTTON_WIDTH,
            BUTTON_HEIGHT,
            "MENU",
            'menu'
        )
        
        self.quit_button = MenuButton(
            SCREEN_WIDTH // 2 + 10,
            SCREEN_HEIGHT // 2 + 100,
            BUTTON_WIDTH,
            BUTTON_HEIGHT,
            "THOÁT",
            'quit'
        )
    
    def draw(self):
        # Semi-transparent overlay
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        overlay.set_alpha(230)
        overlay.fill(BLACK)
        self.screen.blit(overlay, (0, 0))
        
        # Title
        font_title = pygame.font.SysFont(FONT_NAME, 72, bold=True)
        color = GREEN if self.victory else RED
        title_text = "CHIẾN THẮNG!" if self.victory else "THUA CUỘC!"
        title = font_title.render(title_text, True, color)
        title_rect = title.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 100))
        self.screen.blit(title, title_rect)
        
        # Score and time
        font_info = pygame.font.SysFont(FONT_NAME, 36)
        
        score_text = font_info.render('Điểm: {}'.format(self.score), True, WHITE)
        score_rect = score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 20))
        self.screen.blit(score_text, score_rect)
        
        if self.victory:
            time_text = font_info.render('Thời gian: {}'.format(self.time_str), True, WHITE)
            time_rect = time_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 20))
            self.screen.blit(time_text, time_rect)
        
        # Buttons
        self.menu_button.draw(self.screen)
        self.quit_button.draw(self.screen)
        
        if self.victory:
            time_text = font_info.render("Thời gian: {}".format(self.time_str), True, BLACK)
            time_rect = time_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 20))
            self.screen.blit(time_text, time_rect)
        
        # Buttons
        self.menu_button.draw(self.screen)
        self.quit_button.draw(self.screen)
    
    def handle_event(self, event):
        menu_result = self.menu_button.handle_event(event)
        if menu_result:
            return menu_result
        
        quit_result = self.quit_button.handle_event(event)
        if quit_result:
            return quit_result
        
        return None

def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Số Liên Tranh Bá")
    clock = pygame.time.Clock()
    
    state = 'menu'
    menu = Menu(screen)
    game = None
    game_over_screen = None
    
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            
            if state == 'menu':
                result = menu.handle_event(event)
                if result:
                    game = Game(result)
                    state = 'game'
            
            elif state == 'game':
                if event.type == pygame.MOUSEMOTION:
                    cell = game.get_cell_at_pos(event.pos)
                    game.hover_cell = cell
                
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    cell = game.get_cell_at_pos(event.pos)
                    if cell:
                        game.handle_cell_click(cell)
                
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        state = 'menu'
                        menu = Menu(screen)
                
                if game.game_over and state == 'game':
                    game_over_screen = GameOverScreen(
                        screen,
                        game.victory,
                        game.score,
                        format_time(game.get_elapsed_time())
                    )
                    state = 'game_over'
            
            elif state == 'game_over':
                result = game_over_screen.handle_event(event)
                if result == 'menu':
                    state = 'menu'
                    menu = Menu(screen)
                elif result == 'quit':
                    running = False
        
        # Draw
        screen.fill(BG_COLOR)
        
        if state == 'menu':
            menu.draw()
        elif state == 'game':
            game.draw(screen)
            
            # Draw back button
            font = pygame.font.SysFont(FONT_NAME, 24)
            back_text = font.render("ESC - Quay lại menu", True, GRAY)
            screen.blit(back_text, (10, 10))
        elif state == 'game_over':
            game.draw(screen)
            game_over_screen.draw()
        
        pygame.display.flip()
        clock.tick(FPS)
    
    pygame.quit()
    sys.exit()

if __name__ == '__main__':
    main()
