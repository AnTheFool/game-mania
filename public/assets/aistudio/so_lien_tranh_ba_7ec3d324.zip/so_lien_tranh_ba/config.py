# Configuration file for Số Liên Tranh Bá

import pygame

# Screen settings
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 700
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)
DARK_GRAY = (100, 100, 100)
LIGHT_GRAY = (50, 50, 50)
GREEN = (0, 255, 100)
RED = (255, 50, 50)
BLUE = (100, 150, 255)
YELLOW = (255, 215, 0)
ORANGE = (255, 165, 0)
PURPLE = (200, 100, 255)
CYAN = (0, 255, 255)
BG_COLOR = BLACK

# Cell colors
CELL_BG = (40, 40, 60)
CELL_BORDER = (100, 150, 200)
CELL_SELECTED = (255, 215, 0)
CELL_HOVER = (80, 100, 150)

# Font
FONT_NAME = 'arial'

# Game modes
MODES = {
    'EASY': {'name': 'DỄ', 'size': 4, 'max_value': 50, 'min_value': 2},
    'MEDIUM': {'name': 'TRUNG BÌNH', 'size': 6, 'max_value': 100, 'min_value': 2},
    'HARD': {'name': 'KHÓ', 'size': 8, 'max_value': 500, 'min_value': 20},
    'EXPERT': {'name': 'SIÊU TRÍ TUỆ', 'size': 10, 'max_value': 1000, 'min_value': 50}
}

# Scoring
SCORE_SAME = 100
SCORE_ONE_ELIMINATED = 50
SCORE_GCD_NO_ELIMINATION = 10

# UI settings
BUTTON_WIDTH = 200
BUTTON_HEIGHT = 50
BUTTON_MARGIN = 20
CELL_MARGIN = 5
SIDE_PANEL_WIDTH = 250
