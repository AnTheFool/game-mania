import math
from typing import Tuple, List, Optional

def gcd(a: int, b: int) -> int:
    """Calculate greatest common divisor"""
    return math.gcd(a, b)

def is_coprime(a: int, b: int) -> bool:
    """Check if two numbers are coprime (GCD = 1)"""
    return gcd(a, b) == 1

def apply_gcd_rule(val1: int, val2: int) -> Tuple[Optional[int], Optional[int], int]:
    """
    Apply the GCD rule to two values
    Returns: (new_val1, new_val2, gcd_value)
    None means the cell should be eliminated
    """
    if val1 == val2:
        return None, None, val1
    
    g = gcd(val1, val2)
    new_val1 = val1 // g
    new_val2 = val2 // g
    
    # If result is 1, eliminate the cell
    if new_val1 == 1:
        new_val1 = None
    if new_val2 == 1:
        new_val2 = None
    
    return new_val1, new_val2, g

def calculate_score(val1: int, val2: int) -> int:
    """Calculate score based on the operation"""
    from config import SCORE_SAME, SCORE_ONE_ELIMINATED, SCORE_GCD_NO_ELIMINATION
    
    if val1 == val2:
        return SCORE_SAME
    
    new_val1, new_val2, _ = apply_gcd_rule(val1, val2)
    
    # Both eliminated or one eliminated
    if new_val1 is None and new_val2 is None:
        return SCORE_SAME
    elif new_val1 is None or new_val2 is None:
        return SCORE_ONE_ELIMINATED
    else:
        return SCORE_GCD_NO_ELIMINATION

def prime_factorization(n: int) -> dict:
    """Return prime factorization as a dictionary {prime: count}"""
    factors = {}
    d = 2
    while d * d <= n:
        while n % d == 0:
            factors[d] = factors.get(d, 0) + 1
            n //= d
        d += 1
    if n > 1:
        factors[n] = factors.get(n, 0) + 1
    return factors

def count_total_prime_factors(numbers: list) -> dict:
    """Count total occurrences of each prime factor across all numbers"""
    total_counts = {}
    for num in numbers:
        if num is None:
            continue
        factors = prime_factorization(num)
        for prime, count in factors.items():
            total_counts[prime] = total_counts.get(prime, 0) + count
    return total_counts

def all_prime_counts_even(numbers: list) -> bool:
    """Check if all prime factors appear an even number of times"""
    counts = count_total_prime_factors(numbers)
    for count in counts.values():
        if count % 2 != 0:
            return False
    return True

def format_time(seconds: float) -> str:
    """Format time as MM:SS"""
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    return str(minutes).zfill(2) + ":" + str(secs).zfill(2)